#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "630cc27445"  # abbreviated commit hash
commit = "630cc27445530ea5f66d073a695e7112021cc8c0"  # commit hash
date = "2021-09-07 19:59:50 +0200"  # commit date
author = "Rok Mandeljc <rok.mandeljc@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """hookutils: qt: fix DLL search path for PySide2 and PySide6

The DLL search path used to resolve import names to fullpaths on
Windows differs between PyQt5/6 and PySide2/6. For the former,
the existing BinariesPath is correct, but for the latter, we need
to use PrefixPath.

Alternatively, we could do away with giving extra search path to
bindepend.getfullnameof(), and instead perform the analysis of
Qt modules' DLL dependencies in an isolated subprocess and with
the main Qt package imported.

But at least for PyPI wheels, giving the search path seems to be
sufficient...
"""
