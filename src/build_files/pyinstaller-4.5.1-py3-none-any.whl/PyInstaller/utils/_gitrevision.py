#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "5a02f55c69"     # abbreviated commit hash
commit = "5a02f55c696f16b98f23a8b487f3daa8f644a8d2"  # commit hash
date = "2021-08-06 18:17:20 +1000"   # commit date
author = "Jasper Harrison <legorooj@protonmail.com>"
ref_names = "tag: v4.5.1"  # incl. current branch
commit_message = """release v4.5.1
"""
