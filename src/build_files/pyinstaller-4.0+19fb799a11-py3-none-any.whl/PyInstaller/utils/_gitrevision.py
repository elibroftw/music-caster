#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "19fb799a11"     # abbreviated commit hash
commit = "19fb799a11d2d796fc8758808f873c40e2bf5118"  # commit hash
date = "2020-08-09 13:36:32 +0200"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "tag: v4.0, master"  # incl. current branch
commit_message = """Release 4.0.
"""
